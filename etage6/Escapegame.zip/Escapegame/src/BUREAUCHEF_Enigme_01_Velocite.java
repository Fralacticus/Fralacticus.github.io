public class BUREAUCHEF_Enigme_01_Velocite {
    public static void main(String[] args) {
        Integer velociteRomain = 1;
        Integer velociteDamien = 1;

        System.out.println("Vélocité identique ? -> "
                + (velociteRomain == velociteDamien));
    }
}
// Solution 128
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

public class LABO_Enigme_02_ANSICouleurs_Partie1_DecodageBase64 {
    public static void main(String[] args) throws Exception {
        String cheminEntree = "";
        String cheminSortie = "";
        // Lire le Base64
        String base64Lu = Files.readString(Path.of(cheminEntree));
        // Décoder
        byte[] decodedBytes = Base64.getDecoder().decode(base64Lu);
        // Écriture du contenu décodé
        Files.write(Path.of(cheminSortie), decodedBytes);
    }
}
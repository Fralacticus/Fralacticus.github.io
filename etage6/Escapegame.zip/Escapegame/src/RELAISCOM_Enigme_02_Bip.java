import java.io.IOException;
import java.nio.file.*;
import java.util.*;

public class RELAISCOM_Enigme_02_Bip {

    static String NOM_FICHIER = "partition_message_detresse.txt";

    static List<Character> LISTE_CHAR_SPECIAUX = List.of(

            // contrôles ASCII sûrs
            '\u0001','\u0002','\u0003','\u0005','\u0006',
            '\u000E','\u000F','\u0010','\u0011','\u0012','\u0013','\u0014',
            '\u0015','\u0016','\u0017','\u0018','\u0019','\u001A',
            '\u001C','\u001D','\u001E',

            // séparateurs Unicode
            '\u2028', // line separator
            '\u2029', // paragraph separator

            // espaces spéciaux
            '\u2000','\u2001','\u2002','\u2003','\u2004',
            '\u2005','\u2006','\u2007','\u2008','\u2009',
            '\u200A',

            // invisibles
            '\u200B', // zero width space
            '\u200C', // zero width non-joiner
            '\u200D', // zero width joiner
            '\u2060', // word joiner


            // contrôles C1 (rarement interprétés)
            '\u0081','\u008D','\u008F','\u0090','\u009D'
    );

    static void ajouterBruit(List<Character> seq, Random rand) {

        int n = rand.nextInt(100); // 0 à 4 caractères spéciaux

        for(int i = 0; i < n; i++) {
            char c = LISTE_CHAR_SPECIAUX.get(rand.nextInt(LISTE_CHAR_SPECIAUX.size()));
            seq.add(c);
        }
    }

    static void genererLettreMorse(char lettre, List<Character> seq, Random rand) {

        final char BELL = '\u0007';
        final char PAUSE = '\u001F';

        int nbPoints = switch (lettre) {
            case 'H' -> 4;
            case 'I' -> 2;
            case 'E' -> 1;
            case 'S' -> 3;
            default -> throw new IllegalArgumentException("Lettre invalide : " + lettre);
        };
        ajouterBruit(seq, rand);
        for(int i = 0; i < nbPoints; i++) {
            seq.add(BELL);
            ajouterBruit(seq, rand);

            if(i < nbPoints - 1) {
                seq.add(PAUSE);
                ajouterBruit(seq, rand);
            }
        }
    }

    static String generer_morse(String motif) {

        final char PAUSE = '\u001F';

        Random rand = new Random();
        List<Character> seq = new ArrayList<>();

        ajouterBruit(seq, rand);

        for(int l = 0; l < motif.length(); l++) {

            char lettre = motif.charAt(l);

            genererLettreMorse(lettre, seq, rand);

            if(l < motif.length() - 1) {
                for(int i = 0; i < 4; i++) {
                    seq.add(PAUSE);
                    ajouterBruit(seq, rand);
                }
            }
        }

        StringBuilder sb = new StringBuilder();

        for(char c : seq) {
            sb.append(c);
        }

        return sb.toString();
    }


    static String generer_bloc(int NB_BELL, int NB_CAR_SPECIAUX) {
        final char PAUSE = '\u001F';
        final char BELL = '\u0007';

        Random rand = new Random();

        List<List<Character>> blocs = new ArrayList<>();

        // blocs PAUSE + BELL
        for(int i = 0; i < NB_BELL; i++) {
            blocs.add(List.of(PAUSE, BELL));
        }

        // blocs simples
        for(int i = 0; i < NB_CAR_SPECIAUX; i++) {
            char c = LISTE_CHAR_SPECIAUX.get(rand.nextInt(LISTE_CHAR_SPECIAUX.size()));
            blocs.add(List.of(c));
        }

        // mélange
        Collections.shuffle(blocs);

        StringBuilder sb = new StringBuilder();

        for(List<Character> bloc : blocs) {
            for(char c : bloc) {
                sb.append(c);
            }
        }
        String texte = sb.toString();

        // afficher positions des BELL
        for (int i = 0; i < texte.length(); i++) {
            if (texte.charAt(i) == BELL) {
                System.out.println("BELL à la position : " + i);
            }
        }

        return texte;
    }

    static void ecrire_fichier() throws IOException {
        final char STOP = '\u0004';
        System.out.println("Bloc enigme");
        String blocEnigme = generer_morse("HIES");
        System.out.println("Bloc piège");
        String blocPiege  = generer_morse("ISEEIHI");
        String texte = blocEnigme + STOP + blocPiege;
        Files.writeString(Path.of(NOM_FICHIER), texte);
        System.out.println("Position STOP = " + (blocEnigme.length()));
    }

    static void SOLUTION_lire_fichier() throws IOException, InterruptedException {
        //final char BELL = '\u0007';
        final char PAUSE = '\u001F';
        final char STOP  = '\u0004';

        String text = Files.readString(Path.of(NOM_FICHIER));

        for(char c : text.toCharArray()) {
            if(c == STOP) {
                break;
            }
            if(c == PAUSE) {
                Thread.sleep(500);
            }
            System.out.print(c);
        }

        // Dans Terminal reel
        // javac .\ RELAISCOM_Enigme_02_Bip
        // java RELAISCOM_Enigme_02_Bip
    }
    public static void main(String[] args) throws InterruptedException, IOException {
        ecrire_fichier();
        SOLUTION_lire_fichier();
    }
}

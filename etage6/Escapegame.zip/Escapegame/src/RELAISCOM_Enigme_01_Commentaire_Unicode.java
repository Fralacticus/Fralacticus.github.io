public class RELAISCOM_Enigme_01_Commentaire_Unicode {
    public static void main(String[] args) {
        // \u000A System.out.println(": CODE D'OUVERTURE");
    }

    // Solution //  \ u 000A System.out.println(": CODE D'OUVERTURE");
}


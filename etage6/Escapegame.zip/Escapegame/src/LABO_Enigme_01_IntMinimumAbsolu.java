public class LABO_Enigme_01_IntMinimumAbsolu {

    public static void main(String[] args) {
        System.out.println(Math.abs(Integer.MIN_VALUE));
    }

    // Solution Integer.MIN_VALUE -> -2147483648

}

import java.nio.file.Files;
import java.nio.file.Path;

    public class BUREAUCHEF_Enigme_02_BitmapPalette {

        public static void main(String[] args) throws Exception {

            // Lit tout le fichier BMP dans un tableau d'octets
            byte[] bmp = Files.readAllBytes(Path.of("peinture.bmp"));

            // Index de la couleur à modifier
            // 243e couleur -> index 242 car les tableaux commencent à 0
            int indexCouleur = 242;

            // 54 = taille de l'en-tête standard d'un BMP :
            // 14 octets (BITMAPFILEHEADER)
            // + 40 octets (BITMAPINFOHEADER)
            // Après ces 54 octets commence la palette de couleurs
            //
            // *4 car chaque entrée de palette BMP occupe 4 octets :
            // 1 octet Bleu
            // 1 octet Vert
            // 1 octet Rouge
            // 1 octet réservé
            //
            // Donc pour atteindre la couleur N : 54 + N * 4
            int offsetPalette = 54 + indexCouleur * 4;

            // On écrit la nouvelle couleur FF00FF (magenta)
            // Attention : BMP stocke les couleurs en ordre BGR et non RGB

            bmp[offsetPalette]     = (byte)0xFF; // Bleu
            bmp[offsetPalette + 1] = (byte)0x00; // Vert
            bmp[offsetPalette + 2] = (byte)0xFF; // Rouge
            bmp[offsetPalette + 3] = (byte)0x00; // Octet réservé (toujours 0)

            // Écrit le fichier BMP modifié
            Files.write(Path.of("peinture_decodee.bmp"), bmp);
        }
    }
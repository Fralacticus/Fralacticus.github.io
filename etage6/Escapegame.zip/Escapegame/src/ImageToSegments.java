//import javax.imageio.ImageIO;
//import java.awt.image.BufferedImage;
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//
//public class ImageToSegments {
//
//    public static void main(String[] args) throws Exception {
//
//        BufferedImage img = ImageIO.read(new File("dragon_origi.png"));
//
//        int scale = 3;
//        int threshold = 128;
//
//        BufferedWriter writer = new BufferedWriter(new FileWriter("segments.txt"));
//
//        for (int y = 0; y < img.getHeight(); y++) {
//
//            int x = 0;
//
//            while (x < img.getWidth()) {
//
//                int rgb = img.getRGB(x, y);
//
//                int r = (rgb >> 16) & 0xFF;
//                int g = (rgb >> 8) & 0xFF;
//                int b = rgb & 0xFF;
//
//                int gray = (r + g + b) / 3;
//
//                if (gray < threshold) {
//
//                    int startX = x;
//
//                    // continuer tant que pixels noirs
//                    while (x < img.getWidth()) {
//
//                        rgb = img.getRGB(x, y);
//
//                        r = (rgb >> 16) & 0xFF;
//                        g = (rgb >> 8) & 0xFF;
//                        b = rgb & 0xFF;
//
//                        gray = (r + g + b) / 3;
//
//                        if (gray >= threshold) break;
//
//                        x++;
//                    }
//
//                    int endX = x - 1;
//
//                    int x1 = startX * scale;
//                    int y1 = y * scale;
//                    int x2 = endX * scale;
//                    int y2 = y1;
//
//                    writer.write(x1 + "," + y1 + "," + x2 + "," + y2);
//                    writer.newLine();
//
//                } else {
//                    x++;
//                }
//            }
//        }
//
//        writer.close();
//
//        System.out.println("Segments écrits dans segments.txt");
//    }
//}


import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ImageToSegments {

    public static void main(String[] args) throws Exception {

        BufferedImage img = ImageIO.read(new File("responsable2.png"));

        int scale = 3;
        int threshold = 110;

        boolean[][] used = new boolean[img.getHeight()][img.getWidth()];

        BufferedWriter writer = new BufferedWriter(new FileWriter("segments.txt"));
        List<String> segments = new ArrayList<>();

        for (int y = 0; y < img.getHeight(); y++) {
            for (int x = 0; x < img.getWidth(); x++) {

                if (used[y][x]) continue;

                int rgb = img.getRGB(x, y);

                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = rgb & 0xFF;

                int gray = (r + g + b) / 3;

                if (gray < threshold) {

                    int startX = x;
                    int startY = y;

                    int cx = x;
                    int cy = y;

                    while (cx < img.getWidth() && cy < img.getHeight()) {

                        rgb = img.getRGB(cx, cy);

                        r = (rgb >> 16) & 0xFF;
                        g = (rgb >> 8) & 0xFF;
                        b = rgb & 0xFF;

                        gray = (r + g + b) / 3;

                        if (gray >= threshold) break;

                        used[cy][cx] = true;

                        cx++;
                        cy++;
                    }

                    int endX = cx - 1;
                    int endY = cy - 1;

                    int x1 = startX * scale;
                    int y1 = startY * scale;
                    int x2 = endX * scale;
                    int y2 = endY * scale;

//                    writer.write(x1 + "," + y1 + "," + x2 + "," + y2);
//                    writer.newLine();
                    segments.add(x1 + "," + y1 + "," + x2 + "," + y2);
                }
            }
        }



        Random rand = new Random();

        int noiseAmount = 0; // bruit max en pixels (±2)

        for (int i = 0; i < segments.size(); i++) {

            String[] p = segments.get(i).split(",");

            int x1 = Integer.parseInt(p[0]);
            int y1 = Integer.parseInt(p[1]);
            int x2 = Integer.parseInt(p[2]);
            int y2 = Integer.parseInt(p[3]);

//            x1 += rand.nextInt(noiseAmount * 2 + 1) - noiseAmount;
//            y1 += rand.nextInt(noiseAmount * 2 + 1) - noiseAmount;
//            x2 += rand.nextInt(noiseAmount * 2 + 1) - noiseAmount;
//            y2 += rand.nextInt(noiseAmount * 2 + 1) - noiseAmount;
//
//            x1 += 33;
//            y1 += -50;
//            x2 += -65;
//            y2 += 42; //42

            segments.set(i, x1 + "," + y1 + "," + x2 + "," + y2);
        }






        //Collections.shuffle(segments);

        for (String s : segments) {
            writer.write(s);
            writer.newLine();
        }

        writer.close();



        System.out.println("Segments diagonaux écrits dans segments.txt");
    }
}